// Start JavaScript for Navbar Functionality
document.addEventListener('DOMContentLoaded', function () {
    // Select all navigation items
    const navItems = document.querySelectorAll('.nav-item');
    // Select all dropdown menus
    const subMenus = document.querySelectorAll('.dropdown-menu, .dropdown-submenu');

    // Start Toggle Submenus on Click for Mobile
    // Add click event listener to each navigation item
    navItems.forEach(item => {
        item.addEventListener('click', function (e) {
            const dropdownMenu = this.querySelector('.dropdown-menu'); // Find dropdown menu for the clicked item
            if (dropdownMenu) {
                e.preventDefault(); // Prevent default link behavior
                dropdownMenu.classList.toggle('show'); // Toggle visibility of the dropdown
            }
        });
    });
    // End Toggle Submenus on Click for Mobile

    // Start Event Listeners for Sub-menu Items
    // Select all links within dropdown items
    const subMenuLinks = document.querySelectorAll('.dropdown-item > a');

    // Add click event listener to each submenu link
    subMenuLinks.forEach(link => {
        link.addEventListener('click', function (e) {
            const parentNavItem = this.closest('.nav-item'); // Get the main menu item
            const dropdownMenu = this.closest('.dropdown-menu'); // Get the parent submenu
            const parentDropdownItem = this.closest('.dropdown-item'); // Get the clicked submenu item

            // Reset colors for all links
            document.querySelectorAll('.nav-item a, .dropdown-item a').forEach(el => {
                el.classList.remove('active'); // Remove active class for all
                el.style.backgroundColor = ''; // Reset background color
                el.style.color = ''; // Reset text color
            });

            // Change colors for clicked submenu and its parent
            parentDropdownItem.classList.add('active'); // Add active class to clicked item
            parentDropdownItem.style.backgroundColor = '#001f3f'; // Change background color
            parentDropdownItem.style.color = '#f0f0f0'; // Change text color

            // Change the parent submenu item color
            if (parentDropdownItem.parentElement.previousElementSibling) {
                const parentSubMenuItem = parentDropdownItem.parentElement.previousElementSibling; // Get the parent submenu item
                parentSubMenuItem.classList.add('active'); // Add active class
                parentSubMenuItem.style.backgroundColor = '#001f3f'; // Change parent submenu background
                parentSubMenuItem.style.color = '#f0f0f0'; // Change parent submenu text color
            }

            // Change the main menu item color
            parentNavItem.querySelector('a').classList.add('active'); // Change parent nav item
            parentNavItem.querySelector('a').style.backgroundColor = '#001f3f'; // Change main menu background
            parentNavItem.querySelector('a').style.color = '#f0f0f0'; // Change main menu text color
        });
    });
    // End Event Listeners for Sub-menu Items

    // Start Sub-submenu Alignment
    // Ensure sub-submenus open adjacent to their parent submenus
    document.querySelectorAll('.dropdown-submenu').forEach(submenu => {
        submenu.style.left = '100%'; // Align sub-submenus directly beside their parent
    });
    // End Sub-submenu Alignment

    // Start Close Dropdowns When Clicking Outside
    // Close dropdowns when clicked outside
    document.addEventListener('click', function (event) {
        const isClickInsideNav = event.target.closest('.navbar'); // Check if click is inside navbar
        if (!isClickInsideNav) {
            subMenus.forEach(subMenu => {
                subMenu.classList.remove('show'); // Hide all submenus
            });
        }
    });
    // End Close Dropdowns When Clicking Outside

    // Start Hover Behavior for Non-Mobile Devices
    // Function to handle hover behavior for non-mobile devices
    const handleHover = function (e) {
        const isMobile = window.innerWidth <= 768; // Check if the device is mobile
        if (!isMobile) { // Only apply hover effect for non-mobile devices
            const dropdownMenu = this.querySelector('.dropdown-menu'); // Find dropdown menu
            if (dropdownMenu) {
                dropdownMenu.classList.toggle('show', e.type === 'mouseenter'); // Show dropdown on hover
            }
        }
    };

    // Add hover event listeners to nav items
    navItems.forEach(item => {
        item.addEventListener('mouseenter', handleHover); // Handle mouse enter
        item.addEventListener('mouseleave', handleHover); // Handle mouse leave
    });
    // End Hover Behavior for Non-Mobile Devices
});
// End JavaScript for Navbar Functionality


